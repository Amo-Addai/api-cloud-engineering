package main

import (
	"bytes"
	"encoding/json"
	"fmt"

	"github.com/aws/aws-lambda-go/events"
	"github.com/aws/aws-lambda-go/lambda"
)

// BodyRequest - Login params
type BodyRequest struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

// Request - AWS Request
type Request events.APIGatewayProxyRequest

// Response - AWS Response
type Response events.APIGatewayProxyResponse

// Handler - main handler
func Handler(request Request) (Response, error) {
	bodyRequest := BodyRequest{
		Username: "",
		Password: "",
	}

	// Unmarshal the json, return 400 if error
	parseErr := json.Unmarshal([]byte(request.Body), &bodyRequest)
	if parseErr != nil {
		return Response{Body: parseErr.Error(), StatusCode: 400}, nil
	}

	// look up user by username and password
	// but really most likely by phone number

	// prepare successful response
	var buf bytes.Buffer
	message := fmt.Sprintf("successful")
	body, err := json.Marshal(map[string]interface{}{"message": message})
	if err != nil {
		return Response{StatusCode: 404}, err
	}
	json.HTMLEscape(&buf, body)

	resp := Response{
		StatusCode:      200,
		IsBase64Encoded: false,
		Body:            buf.String(),
		Headers: map[string]string{
			"Content-Type": "application/json",
		},
	}

	return resp, nil
}

func main() {
	lambda.Start(Handler)
}
