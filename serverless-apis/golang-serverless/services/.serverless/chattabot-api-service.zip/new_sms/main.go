package main

import (
	"fmt"
	"log"
	"net/url"
	"time"

	"bitbucket.org/itshospitality/chattabot-api/services/new_sms/models"
	"github.com/aws/aws-lambda-go/events"
	"github.com/aws/aws-lambda-go/lambda"
)

// BodyRequest - Login params
type BodyRequest struct {
	Username string `json:"username"`
	Password string `json:"password"`
}

// Response - AWS Response
type Response events.APIGatewayProxyResponse

// Handler - main handler
func Handler(request events.APIGatewayProxyRequest) (Response, error) {
	environment := models.NewEnvironment()
	if environment.Debug {
		log.Printf("topicURL: %s", environment.TopicURL)
	}

	data, err := url.ParseQuery(request.Body)
	if err != nil {
		log.Print("Unable to parse body")
		return Response{
			StatusCode: 503,
		}, nil
	}

	// validate webhook
	twilio := models.NewTexter(environment.TwilioPhoneNumber, environment.TwilioAuthToken, environment.TwilioAccountSid, environment.ThisURL, data, environment.Debug)
	if !twilio.ValidateWebhook(request) {
		log.Print("Unable to validate webhook")
		return Response{
			StatusCode:      200,
			IsBase64Encoded: false,
			Headers: map[string]string{
				"Content-Type": "application/xml",
			},
		}, nil
	}

	// validate params
	fromPhoneNumber := data.Get("From")
	toPhoneNumber := data.Get("To")
	body := data.Get("Body")
	if fromPhoneNumber == "" {
		log.Print("Missing From")
		return Response{
			StatusCode: 403,
		}, nil
	}

	// debug
	if environment.Debug {
		log.Printf("fromPhoneNumber: %s", fromPhoneNumber)
		log.Printf("toPhoneNumber: %s", toPhoneNumber)
		log.Printf("body: %s", body)
	}

	// send to topic
	event := fmt.Sprintf(`{"fromPhoneNumber": "%s", "toPhoneNumber": "%s", "body": "%s", "createdAt": "%s"}`, fromPhoneNumber, toPhoneNumber, body, time.Now().Format(time.RFC3339))
	publisher := models.NewEventPublisher(environment.TopicURL)
	publisher.PublishEvent(event)

	// success
	resp := Response{
		StatusCode:      200,
		IsBase64Encoded: false,
		Headers: map[string]string{
			"Content-Type": "application/xml",
		},
	}

	log.Print("Processed!")
	return resp, nil
}

func main() {
	lambda.Start(Handler)
}
