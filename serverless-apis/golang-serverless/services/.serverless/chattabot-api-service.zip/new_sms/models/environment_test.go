package models

import (
	"github.com/stretchr/testify/assert"

	"testing"
)

func TestGetHotelFromPhoneNumber(t *testing.T) {
	environment := NewEnvironment()
	assert.Equal(t, false, environment.Debug)
}
