package models

import (
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/sns"
)

// EventPublisher - the object that can publish events
type EventPublisher struct {
	snsSession *sns.SNS
	topicARN   *string
}

// NewEventPublisher - Create a new event publisher
func NewEventPublisher(topicARN string) *EventPublisher {
	return &EventPublisher{
		snsSession: sns.New(session.New()),
		topicARN:   aws.String(topicARN),
	}
}

// PublishEvent - publish event
func (eventPublisher *EventPublisher) PublishEvent(body string) error {
	params := &sns.PublishInput{
		Message:  aws.String(body),
		TopicArn: eventPublisher.topicARN,
	}

	_, err := eventPublisher.snsSession.Publish(params)
	return err
}
