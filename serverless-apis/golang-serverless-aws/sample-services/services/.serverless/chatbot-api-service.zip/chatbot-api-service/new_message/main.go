package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"log"
	"os"
	"strconv"
	"time"

	"github.com/aws/aws-lambda-go/events"
	"github.com/aws/aws-lambda-go/lambda"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/awserr"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/dynamodb"
	"github.com/google/uuid"
	"github.com/guregu/dynamo"
)

// Message - Login params
type Message struct {
	FromPhoneNumber string `json:"fromPhoneNumber"`
	ToPhoneNumber   string `json:"toPhoneNumber"`
	Body            string `json:"body"`
	CreatedAt       string `json:"createdAt"`
}

// Conversation - conversation
type Conversation struct {
	PhoneGuest       string `dynamo:"phone_guest"`
	PhoneDestination string `dynamo:"phone_dest"`
	ConversationID   string `dynamo:"conversation_id"`
	GuestGUID        string `dynamo:"guest_guid"`
	DestinationGUID  string `dynamo:"dest_guid"`
	CreatedAt        string `dynamo:"created_at"`
}

// ConversationMessage - the conversation message
type ConversationMessage struct {
	ConversationID string `dynamo:"conversation_id"`
	CreatedAt      string `dynamo:"created_at"`
	SenderGUID     string `dynamo:"sender_guid"`
	RecipientGUID  string `dynamo:"recipient_guid"`
}

// Request - AWS Request
type Request events.APIGatewayProxyRequest

// Response - AWS Response
type Response events.APIGatewayProxyResponse

func getEnv(key, fallback string) string {
	if value, ok := os.LookupEnv(key); ok {
		return value
	}
	return fallback
}

func getDebug() bool {
	if debug, debugError := strconv.ParseBool(getEnv("DEBUG", "false")); debugError == nil {
		return debug
	}
	return false
}

func createSuccessfulResponse() (Response, error) {
	var buf bytes.Buffer
	message := fmt.Sprintf("successful")
	body, err := json.Marshal(map[string]interface{}{"message": message})
	if err != nil {
		return Response{StatusCode: 404}, err
	}
	json.HTMLEscape(&buf, body)
	resp := Response{
		StatusCode:      200,
		IsBase64Encoded: false,
		Body:            buf.String(),
		Headers: map[string]string{
			"Content-Type": "application/json",
		},
	}

	return resp, nil
}

func parseEvent(snsEvent events.SNSEvent) []Message {
	var messages []Message
	for _, record := range snsEvent.Records {
		snsRecord := record.SNS
		message := &Message{
			FromPhoneNumber: "",
			ToPhoneNumber:   "",
			Body:            "",
			CreatedAt:       "",
		}
		parseErr := json.Unmarshal([]byte(snsRecord.Message), &message)
		if parseErr == nil {
			messages = append(messages, *message)
		} else {
			log.Print("FAILURE, need to put this into a DLQ")
			fmt.Printf("[%s %s] Message = %s \n", record.EventSource, snsRecord.Timestamp, snsRecord.Message)
		}
	}

	return messages
}

func openDBConn(debug bool) (conversationTable dynamo.Table, messageTable dynamo.Table) {
	region := os.Getenv("REGION")
	db := dynamo.New(session.New(), &aws.Config{Region: aws.String(region)})

	if debug {
		log.Print(os.Getenv("CONVERSATIONS_TABLENAME"))
		log.Print(os.Getenv("MESSAGES_TABLENAME"))
		log.Print(region)
	}

	return db.Table(os.Getenv("CONVERSATIONS_TABLENAME")), db.Table(os.Getenv("MESSAGES_TABLENAME"))
}

func findConversation(table dynamo.Table, phoneGuest string, phoneDest string) (*Conversation, error) {
	conversation := &Conversation{}
	return conversation, table.Get("phone_guest", phoneGuest).Range("phone_dest", dynamo.Equal, phoneDest).One(&conversation)
}

func addConversation(table dynamo.Table, message *Message) (*Conversation, error) {
	conversation := &Conversation{
		PhoneGuest:       message.FromPhoneNumber,
		PhoneDestination: message.ToPhoneNumber,
		ConversationID:   uuid.New().String(),
		GuestGUID:        uuid.New().String(),
		DestinationGUID:  uuid.New().String(),
		CreatedAt:        time.Now().Format(time.RFC3339),
	}
	return conversation, table.Put(conversation).Run()
}

func addConversationMessage(table dynamo.Table, now string, conversation *Conversation) error {
	conversationMessage := &ConversationMessage{
		ConversationID: conversation.ConversationID,
		CreatedAt:      now,
		SenderGUID:     conversation.GuestGUID,
		RecipientGUID:  conversation.DestinationGUID,
	}
	return table.Put(conversationMessage).Run()
}

// Handler - main handler
func Handler(ctx context.Context, snsEvent events.SNSEvent) (Response, error) {
	log.Print("new_message start")
	debug := getDebug()

	messages := parseEvent(snsEvent)
	if debug {
		log.Print(messages)
	}

	conversationsTable, messagesTable := openDBConn(debug)
	now := time.Now().Format(time.RFC3339)
	for _, message := range messages {
		var c *Conversation
		conversation, findConversationErr := findConversation(conversationsTable, message.ToPhoneNumber, message.FromPhoneNumber)
		c = conversation
		if findConversationErr != nil {
			if findConversationErr == dynamo.ErrNotFound {
				if debug {
					log.Print("No convo found, from orm")
				}
			} else {
				if aerr, ok := findConversationErr.(awserr.Error); ok {
					if aerr.Code() == dynamodb.ErrCodeResourceNotFoundException {
						if debug {
							log.Print("No convo found, from dynamodb")
						}
					}
				} else {
					log.Print("Error while trying to find existing conversation")
					log.Print(findConversationErr)
					continue
				}
			}

			conversation, addConversationError := addConversation(conversationsTable, &message)
			c = conversation
			if addConversationError != nil {
				log.Print("Error while trying to add conversation")
				log.Print(addConversationError)
				continue
			}
			if debug {
				log.Print("New conversation created!")
			}
		}

		// conversation exists
		addConversationMessageError := addConversationMessage(messagesTable, now, c)
		if addConversationMessageError != nil {
			log.Print("Error while trying to add message")
			log.Print(addConversationMessageError)
			continue
		}

		if debug {
			log.Print("New message created!")
		}
	}

	return createSuccessfulResponse()
}

func main() {
	lambda.Start(Handler)
}
